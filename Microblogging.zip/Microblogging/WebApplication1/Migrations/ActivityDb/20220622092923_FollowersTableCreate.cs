﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication1.Migrations.ActivityDb
{
    public partial class FollowersTableCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "userFollowers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FollowersId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CurrerentUserId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FollowersName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FallowersProfileUrl = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userFollowers", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "userFollowers");
        }
    }
}
