﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Azure.Documents;
using System.Security.Claims;
using WebApplication1.Data;
using WebApplication1.Models;
using WebApplication1.Service;

namespace WebApplication1.Repository
{
    public class AccountRepository : IAccountRepository
    {
        private readonly ActivityDbContext _db;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        //private readonly UserService _userService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AccountRepository(UserManager<ApplicationUser> userManager, IHttpContextAccessor httpContextAccessor,
            SignInManager<ApplicationUser> signInManager,
            ActivityDbContext db)//, UserService userService)
        {
            _userManager = userManager;
            _httpContextAccessor = httpContextAccessor;
            _signInManager = signInManager;
            _db = db;
          //  _userService = userService;
        }
      public  async Task<IdentityResult> CreateAsync(SignUpModel upModel)
        {
            var user = new ApplicationUser()
            {
                Email = upModel.Email,
                UserName = upModel.Email,
                FirstName = upModel.FirstName,
                LastName = upModel.LastName,
              //  CountryOfRedience = upModel.CountryOfRedsidence,
                PhoneNumber = upModel.ContactNumber,
                ProfileImageUrl = upModel.ProfileImageUrl
            };
            var result = await _userManager.CreateAsync(user, upModel.Password);
            return result;
        }
        public async Task<SignInResult> PasswordSignInAsync(SignInModel inModel)
        {
         var result =   await  _signInManager.PasswordSignInAsync(inModel.Email, inModel.Password, true, false);
            return result;
        }
        public async Task SignOutAynac()
        {
            await _signInManager.SignOutAsync();
        }
        public  List<SignUpModel> GetAllUser()
        { 
             var users = new List<SignUpModel>();
            var  data = _userManager.Users.ToList();
            if(data.Count > 0)
            {
                foreach (var user in data)
                {
                    users.Add(new SignUpModel()
                    {
                        FirstName = user.FirstName,
                        LastName= user.LastName,
                        ProfileImageUrl =user.ProfileImageUrl,
                        Email = user.Email,
                        ID = user.Id

                    });

                }
            }
            return users;

        }
        public async void Follow(string id)
        {

            var userFollow =  _userManager.Users.FirstOrDefault(u=>u.Id==id);
            var currentUserId = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var currentUser = _userManager.Users.FirstOrDefault(u=>u.Id==currentUserId);
            if (currentUser != null && userFollow != null)
            {
                var follow = new UserFollow()
                {
                    UId = currentUserId,
                    FId = id,
                    FallowProfileUrl = userFollow?.ProfileImageUrl,
                    FollowName = userFollow?.FirstName

                };

                await _db.userFollows.AddAsync(follow);
                if(currentUser != null)
                currentUser.Follow += 1;
                _db.SaveChanges();

                var followers = new UserFollowers()
                {
                    FallowersProfileUrl = currentUser?.ProfileImageUrl,
                    CurrerentUserId = id,
                    FollowersId = currentUserId,
                    FollowersName = currentUser?.FirstName
                };

                await _db.userFollowers.AddAsync(followers);
                if(userFollow!=null)
                userFollow.Followers += 1;
                _db.SaveChanges();
            }

        }

        //public  ApplicationUser FindByIdAsync(string id)
        //{
            
        //        var result = _userManager.Users.FirstOrDefault(u => u.Id == id);
        //    if (result != null)
        //    {
        //        return result;
        //    }
           
          
        //}

        public List<UserFollow> GetUserFollows()
        {
            var currentUserId = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var data = _db.userFollows.ToList();
            var Follows = new List<UserFollow>();
            if (data.Count > 0)
            {
                foreach (var userFollow in data)
                {
                    if (currentUserId == userFollow.UId)
                    {
                        Follows.Add(new UserFollow()
                        {
                            UId = userFollow.UId,
                            FId = userFollow.FId,
                            FallowProfileUrl = userFollow.FallowProfileUrl,
                            FollowName = userFollow.FollowName
                        });
                    }
                }
            }
            return Follows;
        }
        public List<UserFollowers> GetUserFollowers()
        {
          
            var currentUserId = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var data = _db.userFollowers.ToList();
            var Followers = new List<UserFollowers>();
            if (data.Count > 0)
            {
                foreach (var userFollow in data)
                {
                    if (currentUserId == userFollow.CurrerentUserId)
                    {
                        Followers.Add(new UserFollowers()
                        {
                            CurrerentUserId = userFollow.CurrerentUserId,
                            FollowersId = userFollow.FollowersId,
                            FallowersProfileUrl = userFollow.FallowersProfileUrl,
                            FollowersName = userFollow.FollowersName
                        });
                    }
                }
            }
            return Followers;
        }
        public void UnFollow(string id)
        {
            var Follow = _userManager.Users.FirstOrDefault(u => u.Id == id);
            var currentUserId = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var currentUser = _userManager.Users.FirstOrDefault(u => u.Id == currentUserId);
            var user = _db.userFollows.ToList();
            foreach(var userFollow in user)
            {
                if(userFollow.FId == id &&userFollow.UId==currentUserId)
                {
                    _db.userFollows.Remove(userFollow);
                    if(currentUser != null)
                    currentUser.Follow -= 1;
                    _db.SaveChanges();
                    break;
                }
            }
            var followers = _db.userFollowers.ToList(); 
            foreach (var userFollow in followers)
            {
                if(userFollow.FollowersId==currentUserId&&userFollow.CurrerentUserId==id)
                {
                    _db.userFollowers.Remove(userFollow);
                    if(Follow != null)
                    Follow.Followers -=1;
                    _db.SaveChanges();
                    break;
                }

            }
        }
        public void PostTweet(string obj)
        {
            var currentUserId = _httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var currentUser = _userManager.Users.FirstOrDefault(u => u.Id == currentUserId);
            if (currentUser != null)
            {
                var data = new Tweets()
                {
                    UserId = currentUserId,
                    UserName = currentUser.FirstName,
                    UserProfile = currentUser.ProfileImageUrl,
                    Tweet = "abcd fvnn fgnbb",
                    NumberOfLike = 0
                };
                _db.tweets.Add(data);
                _db.SaveChanges();
            }
        }

    }

}
