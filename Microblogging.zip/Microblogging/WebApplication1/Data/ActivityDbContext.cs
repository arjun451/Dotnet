﻿using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Data
{
    public class ActivityDbContext:DbContext
    {
        public ActivityDbContext(DbContextOptions<ActivityDbContext> options):base(options)
        {

        }
      public  DbSet<UserFollow> userFollows { get; set; }
      public DbSet<UserFollowers> userFollowers { get; set; }
      public DbSet<Tweets> tweets { get; set; }
    }
}
