﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountRepository _accountRepository;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public AccountController(IAccountRepository accountRepository ,IWebHostEnvironment webHostEnvironment)
        {
            _accountRepository = accountRepository;
             _webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Index()
        {
            return View();
        }
       
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignUp(SignUpModel upModel)
        {
            if (upModel.ProfileImage != null)
            {
                string folder = "ProfileImage/" + Guid.NewGuid().ToString() + "_" + upModel.ProfileImage.FileName;
                upModel.ProfileImageUrl ="/"+ folder;
                string serverFolder = Path.Combine(_webHostEnvironment.WebRootPath, folder);
                await upModel.ProfileImage.CopyToAsync(new FileStream(serverFolder, FileMode.Create));
            }
        //    if (ModelState.IsValid)
       //     {
               
                var result = await _accountRepository.CreateAsync(upModel);
            TempData["success"] = "Account Created";
                if(!result.Succeeded)
                {
                    foreach(var errorMessame in result.Errors)
                    {
                        ModelState.AddModelError("", errorMessame.Description);
                    }
                }
                ModelState.Clear();
            //   }
            return RedirectToAction("SignIn");
        }


        public IActionResult SignIn()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult>  SignIn(SignInModel inModel)
        {
            if(ModelState.IsValid)
            {
                var result = await _accountRepository.PasswordSignInAsync(inModel);
                TempData["success"] = "Login Successfully";
                if (result.Succeeded)
                {
                    return RedirectToAction("Index","Home");
                }
                ModelState.AddModelError("", "Invalid credentials");
            }
            return View();
        }
        
        public async Task <IActionResult> Logout()
        {
          await  _accountRepository.SignOutAynac();
            TempData["success"] = "Logout Successfully";
            return RedirectToAction("SignIn");
        }

        [Authorize]
        public IActionResult GetAllUser()
        {
            var data = _accountRepository.GetAllUser();
            return View(data);
        }
        public  IActionResult CreateFollow(string id)
        {
            if (id != null)
            {
                _accountRepository.Follow(id);
            }
            return View("Index" );
        }

        public IActionResult GetAllFollows()
        {
            var data = _accountRepository.GetUserFollows();
            return View(data);
        }
        public IActionResult GetAllFollowers()
        {
            var data = _accountRepository.GetUserFollowers();
            return View(data);
        }

        public IActionResult UnFollow(string id)
        {
            if (id != null)
            {
                _accountRepository.UnFollow(id);
            }
            return View("Index");
        }
        public IActionResult Tweets()
        {
            
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Tweets( string obj)
        {
            if (obj != null)
            {
                _accountRepository.PostTweet(obj);
            }
            return View();
        }
    }
}
