﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication1.Models
{
    public class UserFollow
    {

        [Key]
        public int Id { get; set; }
        public string? FId { get; set; }
        [Required]
        public string? UId { get; set; }
        [Required]

        public string? FollowName { get; set; }
        [Required]
        public string? FallowProfileUrl { get; set; }
         
    }
}
