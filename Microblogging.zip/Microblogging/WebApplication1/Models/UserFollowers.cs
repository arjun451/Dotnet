﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class UserFollowers
    {
        [Key]
        public int Id { get; set; }
        public string? FollowersId { get; set; }
        [Required]
        public string? CurrerentUserId { get; set; }
        [Required]

        public string? FollowersName { get; set; }
        [Required]
        public string? FallowersProfileUrl { get; set; }
    }
}
