﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Tweets
    {
        [Key]
        public int TweetId { get; set; }
        [Required]
        public DateTime TweetDate { get; set; } = DateTime.Today;
        [Required]
        public string? UserId { get; set; }
        [Required]
        public string? UserName { get; set; }
        [Required]
        public string? UserProfile { get; set; }
        public int  NumberOfLike { get; set; }
        [Required]
        [StringLength(240)]
        public string? Tweet { get; set; }

    }
}
